var connection = require('./../config');

module.exports.addbook=function(req,res){
    
    var today = new Date();
    var book={
        "name":req.body.book_name,
        "author":req.body.author_name,
        "created_at":today,
    }
    connection.query('INSERT INTO book SET ?',book, function (error, results, fields) {
      if (error) {
        res.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
          res.write("<h1>Book Added successesfully</h1>");
          res.write("<a href='/login/add_book'>Add Book</a>  | <a href='/login/delete_book'>Delete Book</a>");
          res.end();
      }
    });
}

module.exports.remove_book=function(req,res){
    var today = new Date();
    var book = req.body.book_name;
    connection.query('DELETE FROM book WHERE name = ?',book, function (error, results, fields) {
      if (error) {
        res.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
        res.write("<h1>Book Deleted successesfully</h1>");
        res.write("<a href='/login/add_book'>Add Book</a>  | <a href='/login/delete_book'>Delete Book</a>");
        res.end();
      }
    });
}