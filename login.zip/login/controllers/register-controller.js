var connection = require('./../config');
module.exports.register=function(req,res){
    var today = new Date();
    var users={
        "name":req.body.name,
        "username":req.body.username,
        "password":req.body.password,
        "created_at":today,
    }
    connection.query('INSERT INTO account SET ?',users, function (error, results, fields) {
      if (error) {
        res.json({
            status:false,
            message:'there are some error with query'
        })
      }else{
          res.write("User register successesfully");
          res.redirect('/login');
      }
    });
}