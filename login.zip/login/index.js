var express=require("express");
var sessions = require('express-session');
var cookieParser = require('cookie-parser');
var bodyParser=require('body-parser');
var app = express();
var authenticateController=require('./controllers/authenticate-controller');
var registerController=require('./controllers/register-controller');
var add_bookController=require('./controllers/addbook');
app.set('view engine', 'pug');
app.set('views','./views');
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(sessions({secret: "Your secret key",saveUninitialized: true,resave: true,}));

var session;
/* route to handle login and registration */


app.use('/login/*',function(req,res,next){
    session = req.session;
    console.log("A request for things received at ");
    if(session.uniqueID){
        next();
    }else{
    res.redirect('/login');
    }
});

app.get('/',function(req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.write("<a href='/login/add_book'>Add Book</a>  | <a href='/login/delete_book'>Delete Book</a>");
    res.end();
});
app.get('/login',function(req,res){
    console.log("in login");
    res.render('login');
});
app.get('/register',function(req,res){
    res.render('register');
});
app.get('/login/add_book',function(req,res){
    res.render('add_book');
});
app.get('/login/remove_book',function(req,res){
    res.render('remove_book');
});

app.post('/login/remove_book',add_bookController.remove_book);
app.post('/login/add_book',add_bookController.addbook);
app.post('/register',registerController.register);
app.post('/login',authenticateController.authenticate);
app.post('/logout', function(req, res){
    req.session.destroy(function(){
       console.log("user logged out.")
    });
    res.redirect('/login');
 });
app.listen(8012);



/*var express = require('express');
var bodyParser = require('body-parser');
var multer = require('multer');
var app = express();



//enable view engine pug
app.set('view engine', 'pug');
app.set('views','./views');

//enable parsering
app.use(bodyParser.json()); 
app.use(bodyParser.urlencoded({ extended: true })); 

//configure router
var routes = require('./routes/routes.js');
app.use('/',routes);


//listening process...
app.listen(4000);*/
